const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const cors = require("cors");

const app = express();
app.use(cors());

const db = new sqlite3.Database("Netflix.db", (err) => {
    if (err) console.error("DB Error:", err);
    else console.log("Connected to SQLite database");
});

// 💥 GET all data  
app.get("/api/netflix", (req, res) => {
    db.all("SELECT * FROM netflix", [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(rows);
    });
});

// 🔥 SEARCH API  
app.get("/search", (req, res) => {
    const q = req.query.query;

    db.all(
        `
        SELECT * FROM netflix
        WHERE title LIKE ? 
        `,
        [`%${q}%`],
        (err, rows) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json(rows);
        }
    );
});

app.listen(5000, () => {
    console.log("Server running on port 5000");
});
