const express = require('express');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = 3000;

// Connect to database
const db = new sqlite3.Database('./netflix.db', (err) => {
  if (err) {
    console.error('Database connection error:', err.message);
  } else {
    console.log('Connected to the Netflix database.');
  }
});

// Default route
app.get('/', (req, res) => {
  res.send('Netflix API is running successfully!');
});

//New route to get all data
app.get('/api/netflix', (req, res) => {
  const sql = 'SELECT * FROM Netflix LIMIT 10'; // adjust table name if needed

  db.all(sql, [], (err, rows) => {
    if (err) {
      console.error('Database query error:', err.message);
      res.status(500).json({ error: err.message });
      return;
    }
    res.json(rows);
  });
});

// Start the server
app.listen(PORT, () => {
  console.log('Server running on http://localhost:${PORT}');
});