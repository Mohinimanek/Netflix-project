async function searchNetflix() {
    const query = document.getElementById("searchInput").value.toLowerCase();
    const resultsDiv = document.getElementById("results");

    resultsDiv.innerHTML = "Loading...";

    try {
        const response = await fetch("http://localhost:3000/api/netflix");

        const data = await response.json();

        const filtered = data.filter(item =>
            item.title.toLowerCase().includes(query)
        );

        if (filtered.length === 0) {
            resultsDiv.innerHTML = "<p>No results found.</p>";
            return;
        }

        resultsDiv.innerHTML = "";

        filtered.forEach(item => {
            const card = document.createElement("div");
            card.classList.add("card");

            card.innerHTML = `
                <h2>${item.title}</h2>
                <p><strong>Type:</strong> ${item.type}</p>
                <p><strong>Release Year:</strong> ${item.release_year}</p>
                <p><strong>Description:</strong> ${item.description}</p>
            `;

            resultsDiv.appendChild(card);
        });

    } catch (error) {
        resultsDiv.innerHTML = "<p>Error fetching data.</p>";
        console.error(error);
    }
}
